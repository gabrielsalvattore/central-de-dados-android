package com.salvatore.centraldados;

import android.app.Activity;
import android.app.PrintManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.print.PrintAttributes;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_OPEN_DATABASE = 1001;
    private static final int REQ_SAVE_FILE = 1002;
    private static final int REQ_BACKUP_FOLDER = 1003;
    private static final int REQ_WEB_FILE = 1004;

    private WebView webView;
    private WebView printWebView;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingContent;
    private String pendingName;
    private String pendingMime;
    private Uri backupTreeUri;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16, 42, 86));
        getWindow().setNavigationBarColor(Color.rgb(16, 42, 86));

        SharedPreferences prefs = getSharedPreferences("central_prefs", MODE_PRIVATE);
        String savedTree = prefs.getString("backup_tree", "");
        if (!savedTree.isEmpty()) backupTreeUri = Uri.parse(savedTree);

        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"file".equals(request.getUrl().getScheme());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (backupTreeUri != null) view.evaluateJavascript("androidBackupEnabled=true;", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, REQ_WEB_FILE);
                    return true;
                } catch (Exception ex) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Não foi possível abrir o seletor de arquivos.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        webView.loadUrl("file:///android_asset/Central_de_Dados.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void openDatabase() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "application/json", "text/plain"});
                startActivityForResult(intent, REQ_OPEN_DATABASE);
            });
        }

        @JavascriptInterface
        public void saveFile(String content, String filename, String mime) {
            runOnUiThread(() -> {
                pendingContent = content;
                pendingName = filename;
                pendingMime = mime;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                intent.putExtra(Intent.EXTRA_TITLE, filename);
                startActivityForResult(intent, REQ_SAVE_FILE);
            });
        }

        @JavascriptInterface
        public void chooseBackupFolder() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, REQ_BACKUP_FOLDER);
            });
        }

        @JavascriptInterface
        public void saveBackup(String content, String filename) {
            runOnUiThread(() -> writeBackup(content, filename));
        }

        @JavascriptInterface
        public void printHtml(String html, String title) {
            runOnUiThread(() -> {
                printWebView = new WebView(MainActivity.this);
                printWebView.getSettings().setJavaScriptEnabled(false);
                printWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        PrintManager manager = (PrintManager) getSystemService(PRINT_SERVICE);
                        manager.print(title, view.createPrintDocumentAdapter(title), new PrintAttributes.Builder().build());
                    }
                });
                printWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }
    }

    private void writeBackup(String content, String filename) {
        if (backupTreeUri == null) {
            toast("Selecione primeiro a pasta de backups.");
            return;
        }
        try {
            String treeId = DocumentsContract.getTreeDocumentId(backupTreeUri);
            Uri parent = DocumentsContract.buildDocumentUriUsingTree(backupTreeUri, treeId);
            Uri file = DocumentsContract.createDocument(getContentResolver(), parent, "application/octet-stream", filename);
            if (file == null) throw new IllegalStateException("Arquivo não criado");
            writeUri(file, content);
        } catch (Exception ex) {
            toast("Falha ao criar o backup no Android.");
        }
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_WEB_FILE) {
            if (fileCallback == null) return;
            Uri[] resultUris = null;
            if (result == RESULT_OK && data != null && data.getData() != null) resultUris = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(resultUris);
            fileCallback = null;
            return;
        }
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (request == REQ_OPEN_DATABASE) {
                String content = readUri(uri);
                String name = queryDisplayName(uri);
                String js = "handleAndroidDatabaseContent(" + JSONObject.quote(content) + "," + JSONObject.quote(name) + ");";
                webView.evaluateJavascript(js, null);
            } else if (request == REQ_SAVE_FILE) {
                writeUri(uri, pendingContent == null ? "" : pendingContent);
                toast((pendingName == null ? "Arquivo" : pendingName) + " salvo com sucesso.");
                pendingContent = pendingName = pendingMime = null;
            } else if (request == REQ_BACKUP_FOLDER) {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags);
                backupTreeUri = uri;
                getSharedPreferences("central_prefs", MODE_PRIVATE).edit().putString("backup_tree", uri.toString()).apply();
                webView.evaluateJavascript("androidBackupFolderReady();", null);
            }
        } catch (Exception ex) {
            toast("Não foi possível concluir a operação com o arquivo.");
        }
    }

    private String readUri(Uri uri) throws Exception {
        StringBuilder out = new StringBuilder();
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) out.append(line).append('\n');
        }
        return out.toString();
    }

    private void writeUri(Uri uri, String content) throws Exception {
        try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
            if (out == null) throw new IllegalStateException("Sem acesso ao arquivo");
            out.write(content.getBytes(StandardCharsets.UTF_8));
            out.flush();
        }
    }

    private String queryDisplayName(Uri uri) {
        try (android.database.Cursor cursor = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) return cursor.getString(0);
        } catch (Exception ignored) { }
        return "BANCO_CENTRAL_DADOS.cdb";
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
