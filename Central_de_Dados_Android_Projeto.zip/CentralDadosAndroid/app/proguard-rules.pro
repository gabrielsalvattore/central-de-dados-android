-keepclassmembers class com.salvatore.centraldados.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
