# Central de Dados — Android

Aplicativo Android offline criado para Salvatore. O projeto incorpora a mesma Central de Dados usada no Windows e adiciona integração nativa para arquivos, impressão e backups.

## Recursos incluídos

- Senha e criptografia AES-GCM.
- Listas, pessoas, CPF único e custos.
- Ajudantes e controle de presença, falta e folga.
- Carros.
- Relatórios em PDF e Excel.
- Abrir, salvar e restaurar bancos `.cdb` pelo seletor de arquivos do Android.
- Pasta persistente para backups automáticos.
- Funcionamento sem internet.
- Crédito “Sistema criado por Salvatore”.

## Abrir e gerar o APK no Android Studio

1. Instale o Android Studio no Windows.
2. Extraia todo o conteúdo do pacote.
3. No Android Studio, escolha **Open** e selecione a pasta `CentralDadosAndroid`.
4. Aguarde a sincronização do Gradle e a instalação do Android SDK 35.
5. Use **Build > Build APK(s)**.
6. O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações

- O arquivo `Central_de_Dados.html` deve permanecer na raiz do projeto. Ele é incorporado automaticamente ao APK durante a compilação.
- Android mínimo: versão 8.0 (API 26).
- O APK de teste é adequado para instalação direta. Para publicar na Play Store, gere uma versão assinada em **Build > Generate Signed App Bundle or APK**.
- Não esqueça a senha: os dados criptografados não podem ser recuperados sem ela.
